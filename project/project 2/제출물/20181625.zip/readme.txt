code 폴더에는 visual studio에서 프로그램 검사를 할 때 사용할 conn_test.cpp 파일이 있습니다. 
system_cls, system_pause x 는 conn_test.cpp와 동일한 파일이지만 컴파일을 진행할 때 system("cls"), 
system("pause")가 실행되지 않을 가능성을 염두하여 해당 부분들을 주석처리한 파일입니다. 
해당 파일을 visual studio에서 실행하게 될 project의 directory에 넣어주시면 되겠습니다. 

CRUD 폴더에는 프로그램에서 사용할 CRUD문이 적힌 .txt 파일들과 .sql 파일이 있습니다. 기본적으로 .txt 파일들을 사용해주시면 됩니다. .sql 폴더의 .sql파일들은 mysql workbench에서 error check할 때 사용한 파일로 혹시 몰라 같이 첨부합니다.